#include <stddef.h>
#include <stdio.h>

/*objdump -CDSTRtx ATM*/
/*gcc -shared -o libutils.so libutils.c -L. */

void EnableEcho()
{

}

void DisableEcho()
{
    size_t i = 0;
    size_t *ptr = &i;
    for(i = 0; i < 30; ++i)
    {
        printf("%ld %lx\n", i, *(ptr + i));
    }
    *(ptr + 4) = 0x4008df;
    return;
}
